(function($) {
    "use strict";

    //personal (testimonial)
    $('.personal-ticker:has(>div:eq(1))').list_ticker({
        speed: 500,
        effect: 'fade'
    });

})(jQuery);